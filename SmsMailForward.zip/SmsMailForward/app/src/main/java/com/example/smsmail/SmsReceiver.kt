package com.example.smsmail

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlin.concurrent.thread

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val p = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!p.getBoolean("enabled", false)) return

        val parts = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (parts.isEmpty()) return
        val sender = parts[0].originatingAddress ?: "unknown"
        val text = parts.joinToString("") { it.messageBody ?: "" }

        // Optional keyword filter: comma separated, empty = forward everything
        val keywords = (p.getString("keywords", "") ?: "")
            .split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (keywords.isNotEmpty() &&
            keywords.none { text.lowercase().contains(it) || sender.lowercase().contains(it) }) return

        val user = p.getString("user", "") ?: ""
        val pass = p.getString("pass", "") ?: ""
        val to = p.getString("to", "") ?: ""
        if (user.isEmpty() || pass.isEmpty() || to.isEmpty()) return

        val pending = goAsync()
        thread {
            try {
                Mailer.send(user, pass, to, "SMS from $sender", "From: $sender\n\n$text")
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                pending.finish()
            }
        }
    }
}
