package com.example.smsmail

import android.Manifest
import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        fun field(hint: String, key: String, pwd: Boolean = false) = EditText(this).apply {
            this.hint = hint
            setText(p.getString(key, ""))
            if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        val user = field("Your Gmail address", "user")
        val pass = field("Gmail App Password (16 chars)", "pass", true)
        val to = field("Send SMS to this email", "to")
        val kw = field("Keywords (optional, comma separated)", "keywords")
        val enabled = Switch(this).apply { text = "Forwarding ON"; isChecked = p.getBoolean("enabled", false) }
        val status = TextView(this)

        fun save() = p.edit()
            .putString("user", user.text.toString().trim())
            .putString("pass", pass.text.toString().replace(" ", ""))
            .putString("to", to.text.toString().trim())
            .putString("keywords", kw.text.toString())
            .putBoolean("enabled", enabled.isChecked).apply()

        val saveBtn = Button(this).apply {
            text = "Save"
            setOnClickListener {
                save()
                requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 1)
                status.text = "Saved."
            }
        }
        val testBtn = Button(this).apply {
            text = "Send test email"
            setOnClickListener {
                save()
                status.text = "Sending..."
                thread {
                    val msg = try {
                        Mailer.send(user.text.toString().trim(), pass.text.toString().replace(" ", ""),
                            to.text.toString().trim(), "Test", "SMS forwarder test OK")
                        "Test email sent."
                    } catch (e: Exception) { "Error: ${e.message}" }
                    runOnUiThread { status.text = msg }
                }
            }
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            listOf<View>(user, pass, to, kw, enabled, saveBtn, testBtn, status).forEach { addView(it) }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
