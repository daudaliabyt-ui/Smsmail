SMS to Email (free, no ads)
1. Install Android Studio, open this folder, let Gradle sync.
2. Run on your phone (USB debugging) or Build > Build APK.
3. Google Account > Security > 2-Step Verification ON > App Passwords > create one.
4. Open app: enter Gmail, app password, destination email. Save, allow SMS permission.
5. Tap "Send test email", then turn Forwarding ON.
Note: some phones (Xiaomi/Oppo/Vivo) need Battery > "No restrictions" + Autostart for the app.
